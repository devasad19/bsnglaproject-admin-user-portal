export type TUser= {
    id: number;
    name: string;
    email: string;
    phone: string;
    role: string;
    status: number;
    created_at: string;
    updated_at: string;
  }
  