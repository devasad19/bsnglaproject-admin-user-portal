import React from "react"

export type ChildrenType = {
    children: React.JSX.Element
};