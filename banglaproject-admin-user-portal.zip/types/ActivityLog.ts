export type TActivityLog = {
  id: number;
  user_id: number;
  type: string;
  description: string;
  created_at: string;
  updated_at: string;
};
