export type AccordionType = {
    icon?: any;
    title: string;
    children: any;
    active?: boolean;
}