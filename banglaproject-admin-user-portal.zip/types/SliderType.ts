export type SliderType = {
    sliders: { image_url: string }[]
}