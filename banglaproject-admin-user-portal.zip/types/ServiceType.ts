export type ServiceType = {
    id: number | any;
    title?: string;
    image?: string | any;
    description?: string;
}