export type ForgotpassType = {
    username: string;
    phone: string;
    email: string;
    password: string;
    confirmPassword: string;
}